/**
 * ============================================================================
 * POKÉMON SAFARI QUEST ENGINE
 * Production-ready Vanilla JavaScript Architecture
 * Author: Portfolio Engineering
 * ============================================================================
 */

/* ==========================================================================
   1. SOUND SYNTHESIS ENGINE (Web Audio API - No External Assets Required)
   ========================================================================== */
class AudioSynthesisEngine {
    constructor() {
        this.ctx = null;
        this.enabled = true;
    }

    init() {
        if (!this.ctx) {
            const AudioContextClass = window.AudioContext || window.webkitAudioContext;
            this.ctx = new AudioContextClass();
        }
        if (this.ctx.state === 'suspended') {
            this.ctx.resume();
        }
    }

    playTone(freq, type = 'sine', duration = 0.15, gainValue = 0.1) {
        if (!this.enabled) return;
        this.init();
        try {
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();

            osc.type = type;
            osc.frequency.setValueAtTime(freq, this.ctx.currentTime);

            gain.gain.setValueAtTime(gainValue, this.ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);

            osc.connect(gain);
            gain.connect(this.ctx.destination);

            osc.start();
            osc.stop(this.ctx.currentTime + duration);
        } catch (e) {
            console.warn('Audio playback error', e);
        }
    }

    playUiClick() {
        this.playTone(800, 'triangle', 0.05, 0.08);
    }

    playBallThrow() {
        this.playTone(320, 'sine', 0.18, 0.12);
        setTimeout(() => this.playTone(580, 'sine', 0.25, 0.15), 100);
    }

    playCatchSuccess() {
        const notes = [523.25, 659.25, 783.99, 1046.50]; // C - E - G - C6 Fanfare
        notes.forEach((freq, idx) => {
            setTimeout(() => this.playTone(freq, 'triangle', 0.2, 0.15), idx * 120);
        });
    }

    playBreakout() {
        this.playTone(180, 'sawtooth', 0.25, 0.12);
    }

    toggle() {
        this.enabled = !this.enabled;
        const btn = document.getElementById('btn-sound-toggle');
        if (btn) btn.innerText = this.enabled ? '🔊 Audio: ON' : '🔇 Audio: OFF';
        if (this.enabled) this.playUiClick();
    }
}

const SoundEngine = new AudioSynthesisEngine();

/* ==========================================================================
   2. POKÉDEX & TRAINER STATIC DATABASE (Production Data Models)
   ========================================================================== */
const TRAINERS_DB = [
    {
        id: 'ash',
        name: 'Ash Ketchum',
        region: 'Kanto Champion',
        avatar: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/trainers/red.png',
        perk: '+15% Electric & Dragon Affinity',
        desc: 'Relentless battle spirit with an unbreakable bond with his partner.'
    },
    {
        id: 'may',
        name: 'May',
        region: 'Hoenn Coordinator',
        avatar: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/trainers/leaf.png',
        perk: '+20% Flee Evasion Prevention',
        desc: 'Graceful tactical coordinator with supreme Safari capture instincts.'
    },
    {
        id: 'dawn',
        name: 'Dawn',
        region: 'Sinnoh Star',
        avatar: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/trainers/erika.png',
        perk: '+10% Critical Capture Chance',
        desc: '"No need to worry!" - Brilliant synchronization with water companions.'
    },
    {
        id: 'serena',
        name: 'Serena',
        region: 'Kalos Queen',
        avatar: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/trainers/beauty.png',
        perk: '+25% Bonus XP from Captures',
        desc: 'Elegant performer whose style inspires maximum friendship.'
    },
    {
        id: 'brock',
        name: 'Brock',
        region: 'Pewter Gym Leader',
        avatar: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/trainers/brock.png',
        perk: '+20% Razz Berry Feeding Efficiency',
        desc: 'Master Pokémon Breeder and Doctor who calms wild creatures instantly.'
    }
];

const STARTER_POKEMON_DB = [
    {
        id: 25,
        name: 'Pikachu',
        ballType: 'Standard Pokéball',
        type: 'Electric',
        color: '#eab308',
        sprite: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/25.png',
        hp: 35, attack: 55, defense: 40, speed: 90,
        lore: 'When several of these Pokémon gather, their electricity could build and cause lightning storms.'
    },
    {
        id: 722,
        name: 'Rowlet',
        ballType: 'Great Ball',
        type: 'Grass / Flying',
        color: '#22c55e',
        sprite: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/722.png',
        hp: 68, attack: 55, defense: 55, speed: 42,
        lore: 'This silent Pokémon glides through the air without making a sound, drawing near to opponents unnoticed.'
    },
    {
        id: 149,
        name: 'Dragonite',
        ballType: 'Ultra Ball',
        type: 'Dragon / Flying',
        color: '#8b5cf6',
        sprite: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/149.png',
        hp: 91, attack: 134, defense: 95, speed: 80,
        lore: 'It is said to make its home somewhere in the countless islands of the sea. It rescues drowning people.'
    }
];

const SAFARI_POKEMON_POOL = [
    {
        id: 149,
        name: 'Dragonite',
        type: 'Dragon / Flying',
        rarity: 'Legendary-Tier',
        baseRate: 0.35,
        cp: 880,
        sprite: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/149.png',
        desc: 'An extremely rare Dragon with benevolent wisdom.'
    },
    {
        id: 722,
        name: 'Rowlet',
        type: 'Grass / Flying',
        rarity: 'Starter',
        baseRate: 0.65,
        cp: 340,
        sprite: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/722.png',
        desc: 'Alolan grass quill Pokémon that turns its head 180 degrees.'
    },
    {
        id: 393,
        name: 'Piplup',
        type: 'Water',
        rarity: 'Common',
        baseRate: 0.75,
        cp: 370,
        sprite: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/393.png',
        desc: 'Proud penguin Pokémon that hates accepting food from strangers.'
    },
    {
        id: 745,
        name: 'Lycanroc Dusk',
        type: 'Rock',
        rarity: 'Rare',
        baseRate: 0.45,
        cp: 690,
        sprite: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/745.png',
        desc: 'A rare sunset evolution with blazing green eyes and fierce loyalty.'
    },
    {
        id: 479,
        name: 'Rotom Dex',
        type: 'Electric / Ghost',
        rarity: 'Special',
        baseRate: 0.60,
        cp: 510,
        sprite: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/479.png',
        desc: 'The intelligent electronic companion capable of speaking human languages.'
    },
    {
        id: 778,
        name: 'Mimikyu',
        type: 'Ghost / Fairy',
        rarity: 'Rare',
        baseRate: 0.40,
        cp: 620,
        sprite: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/778.png',
        desc: 'Wears a rag resembling Pikachu so that it can be loved by others.'
    },
    {
        id: 724,
        name: 'Decidueye',
        type: 'Grass / Ghost',
        rarity: 'Epic',
        baseRate: 0.35,
        cp: 790,
        sprite: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/724.png',
        desc: 'Arrow-quill master with 0.1 second reaction shot precision.'
    },
    {
        id: 727,
        name: 'Incineroar',
        type: 'Fire / Dark',
        rarity: 'Epic',
        baseRate: 0.35,
        cp: 820,
        sprite: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/727.png',
        desc: 'Heel wrestler tiger with intense flame championship belt.'
    },
    {
        id: 791,
        name: 'Solgaleo',
        type: 'Psychic / Steel',
        rarity: 'Mythic',
        baseRate: 0.20,
        cp: 1250,
        sprite: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/791.png',
        desc: 'Radiant beast of the sun honored as an emissary of light.'
    },
    {
        id: 792,
        name: 'Lunala',
        type: 'Psychic / Ghost',
        rarity: 'Mythic',
        baseRate: 0.20,
        cp: 1250,
        sprite: 'https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/792.png',
        desc: 'Emissary of the moon that devours light and bathes the world in night.'
    }
];

const BALL_ARSENAL = [
    { type: 'poke', name: 'Poké Ball', multiplier: 1.0, count: 20, icon: '🔴' },
    { type: 'great', name: 'Great Ball', multiplier: 1.5, count: 10, icon: '🔵' },
    { type: 'ultra', name: 'Ultra Ball', multiplier: 2.0, count: 5, icon: '🟡' },
    { type: 'master', name: 'Master Ball', multiplier: 99.0, count: 1, icon: '🟣' }
];

/* ==========================================================================
   3. STATE MANAGER (With LocalStorage Persistence)
   ========================================================================== */
class GameStateManager {
    constructor() {
        this.storageKey = 'POKEMON_SAFARI_ENGINE_V1';
        this.state = this.loadState();
    }

    getDefaultState() {
        return {
            trainerName: 'Ash Ketchum',
            selectedTrainerId: 'ash',
            selectedStarterIndex: 0,
            level: 1,
            exp: 15,
            score: 0,
            streak: 0,
            razzBerries: 5,
            activeBall: 'poke',
            razzActive: false,
            inventory: {
                poke: 20,
                great: 10,
                ultra: 5,
                master: 1
            },
            caughtRoster: []
        };
    }

    loadState() {
        try {
            const raw = localStorage.getItem(this.storageKey);
            return raw ? JSON.parse(raw) : this.getDefaultState();
        } catch (e) {
            return this.getDefaultState();
        }
    }

    saveState() {
        try {
            localStorage.setItem(this.storageKey, JSON.stringify(this.state));
        } catch (e) {
            console.error('State persistence error', e);
        }
    }

    reset() {
        this.state = this.getDefaultState();
        this.saveState();
    }
}

const Store = new GameStateManager();

/* ==========================================================================
   4. PARTICLE & AMBIENT CANVAS CONTROLLER
   ========================================================================== */
class AmbientCanvas {
    constructor() {
        this.canvas = document.getElementById('ambient-canvas');
        if (!this.canvas) return;
        this.ctx = this.canvas.getContext('2d');
        this.particles = [];
        this.init();
    }

    init() {
        this.resize();
        window.addEventListener('resize', () => this.resize());

        for (let i = 0; i < 40; i++) {
            this.particles.push({
                x: Math.random() * this.canvas.width,
                y: Math.random() * this.canvas.height,
                radius: Math.random() * 2 + 0.5,
                vx: (Math.random() - 0.5) * 0.4,
                vy: (Math.random() - 0.5) * 0.4,
                alpha: Math.random() * 0.5 + 0.2
            });
        }
        this.loop();
    }

    resize() {
        this.canvas.width = window.innerWidth;
        this.canvas.height = window.innerHeight;
    }

    loop() {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

        this.particles.forEach(p => {
            p.x += p.vx;
            p.y += p.vy;

            if (p.x < 0) p.x = this.canvas.width;
            if (p.x > this.canvas.width) p.x = 0;
            if (p.y < 0) p.y = this.canvas.height;
            if (p.y > this.canvas.height) p.y = 0;

            this.ctx.beginPath();
            this.ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
            this.ctx.fillStyle = `rgba(56, 189, 248, ${p.alpha})`;
            this.ctx.fill();
        });

        requestAnimationFrame(() => this.loop());
    }
}

/* ==========================================================================
   5. SAFARI ZONE INTERACTION & CAPTURE CONTROLLER
   ========================================================================== */
class SafariZoneController {
    constructor() {
        this.container = document.getElementById('pokemon-spawn-layer');
    }

    spawnNewWave() {
        SoundEngine.playUiClick();
        if (!this.container) return;
        this.container.innerHTML = '';

        const shuffled = [...SAFARI_POKEMON_POOL].sort(() => 0.5 - Math.random());
        const wave = shuffled.slice(0, 5);

        wave.forEach((poke, index) => {
            const card = document.createElement('div');
            card.className = 'wild-entity';

            // Distinct positions without collision
            const leftOffset = 8 + (index * 18) + (Math.random() * 4);
            const topOffset = 20 + (Math.random() * 45);

            card.style.left = `${leftOffset}%`;
            card.style.top = `${topOffset}%`;

            card.innerHTML = `
                <div class="wild-sprite-wrap">
                    <img src="${poke.sprite}" alt="${poke.name}" loading="lazy">
                </div>
                <div class="wild-name">${poke.name}</div>
                <div class="wild-specs">CP ${poke.cp} • ${poke.rarity}</div>
                <button class="btn-catch-action" onclick="event.stopPropagation(); SafariZone.executeCapture(${JSON.stringify(poke).replace(/"/g, '&quot;')}, this.parentElement)">
                    🎯 CAPTURE
                </button>
            `;

            card.onclick = () => this.executeCapture(poke, card);
            this.container.appendChild(card);
        });
    }

    toggleRazzBerry() {
        SoundEngine.playUiClick();
        if (Store.state.razzBerries <= 0) {
            alert('Out of Razz Berries!');
            return;
        }
        Store.state.razzActive = !Store.state.razzActive;
        const btn = document.getElementById('btn-razz-berry');
        if (Store.state.razzActive) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    }

    executeCapture(poke, cardEl) {
        const ballKey = Store.state.activeBall;
        if (Store.state.inventory[ballKey] <= 0) {
            alert(`You have depleted your stock of ${ballKey.toUpperCase()} BALLS! Switch to another ball type.`);
            return;
        }

        Store.state.inventory[ballKey]--;
        SoundEngine.playBallThrow();

        // Ball Multipliers
        const ballObj = BALL_ARSENAL.find(b => b.type === ballKey) || BALL_ARSENAL[0];
        let catchMultiplier = ballObj.multiplier;

        if (Store.state.razzActive && Store.state.razzBerries > 0) {
            catchMultiplier += 0.35;
            Store.state.razzBerries--;
            Store.state.razzActive = false;
            document.getElementById('btn-razz-berry')?.classList.remove('active');
        }

        const successThreshold = Math.min(0.98, poke.baseRate * catchMultiplier);
        const roll = Math.random();

        // Visual Ball flight physics simulation
        this.animateBallThrow(cardEl, () => {
            if (roll <= successThreshold || ballKey === 'master') {
                // Catch Success
                SoundEngine.playCatchSuccess();
                cardEl.remove();

                Store.state.streak++;
                Store.state.score += Math.floor(poke.cp * (1 + Store.state.streak * 0.1));
                Store.state.exp += 35;
                if (Store.state.exp >= 100) {
                    Store.state.level++;
                    Store.state.exp = Store.state.exp % 100;
                    Store.state.inventory.great += 3;
                    Store.state.inventory.ultra += 1;
                }

                Store.state.caughtRoster.unshift({
                    ...poke,
                    caughtDate: new Date().toLocaleTimeString()
                });

                Store.saveState();
                GameApp.renderHud();
                GameApp.renderSatchel();
                GameApp.setSpotlight(poke);

                if (this.container.querySelectorAll('.wild-entity').length === 0) {
                    setTimeout(() => this.spawnNewWave(), 800);
                }
            } else {
                // Breakout
                SoundEngine.playBreakout();
                Store.state.streak = 0;
                Store.saveState();
                GameApp.renderHud();
                alert(`Oh no! ${poke.name} broke free from the ${ballObj.name}! Try again!`);
            }
        });
    }

    animateBallThrow(targetEl, callback) {
        const canvas = document.getElementById('throw-canvas');
        if (!canvas) {
            callback();
            return;
        }
        const ctx = canvas.getContext('2d');
        canvas.width = canvas.parentElement.clientWidth;
        canvas.height = canvas.parentElement.clientHeight;

        const targetRect = targetEl.getBoundingClientRect();
        const parentRect = canvas.parentElement.getBoundingClientRect();

        const startX = canvas.width / 2;
        const startY = canvas.height - 20;
        const endX = targetRect.left - parentRect.left + (targetRect.width / 2);
        const endY = targetRect.top - parentRect.top + (targetRect.height / 2);

        let progress = 0;
        function renderThrow() {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            progress += 0.05;

            // Quadratic bezier curve arc
            const currentX = (1 - progress) * (1 - progress) * startX + 2 * (1 - progress) * progress * (startX + (endX - startX) * 0.5) + progress * progress * endX;
            const currentY = (1 - progress) * (1 - progress) * startY + 2 * (1 - progress) * progress * (endY - 120) + progress * progress * endY;

            ctx.beginPath();
            ctx.arc(currentX, currentY, 12, 0, Math.PI * 2);
            ctx.fillStyle = '#ef4444';
            ctx.fill();
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 2;
            ctx.stroke();

            if (progress < 1) {
                requestAnimationFrame(renderThrow);
            } else {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
                callback();
            }
        }
        renderThrow();
    }
}

const SafariZone = new SafariZoneController();

/* ==========================================================================
   6. MASTER APPLICATION CONTROLLER
   ========================================================================== */
class SafariQuestApp {
    init() {
        this.renderOnboarding();
        new AmbientCanvas();

        if (Store.state.caughtRoster.length > 0) {
            this.setSpotlight(Store.state.caughtRoster[0]);
        } else {
            this.setSpotlight(STARTER_POKEMON_DB[0]);
        }
    }

    randomizeName() {
        SoundEngine.playUiClick();
        const prefixes = ['Red', 'Ash', 'Dawn', 'Lucas', 'Serena', 'Calem', 'Hau', 'Gladion', 'Cynthia'];
        const chosen = prefixes[Math.floor(Math.random() * prefixes.length)];
        const input = document.getElementById('trainer-name-input');
        if (input) input.value = `${chosen} ${Math.floor(Math.random() * 900 + 100)}`;
    }

    renderOnboarding() {
        // Render Trainer Cards
        const tGrid = document.getElementById('trainer-selection-grid');
        if (tGrid) {
            tGrid.innerHTML = '';
            TRAINERS_DB.forEach(t => {
                const card = document.createElement('div');
                card.className = `trainer-card ${t.id === Store.state.selectedTrainerId ? 'selected' : ''}`;
                card.innerHTML = `
                    <div class="trainer-img-wrap">
                        <img src="${t.avatar}" alt="${t.name}" class="trainer-img">
                    </div>
                    <div class="trainer-name">${t.name}</div>
                    <div class="trainer-title">${t.region}</div>
                    <div class="trainer-perk">${t.perk}</div>
                `;
                card.onclick = () => {
                    SoundEngine.playUiClick();
                    Store.state.selectedTrainerId = t.id;
                    document.querySelectorAll('.trainer-card').forEach(el => el.classList.remove('selected'));
                    card.classList.add('selected');
                };
                tGrid.appendChild(card);
            });
        }

        // Render Starter Capsules
        const sGrid = document.getElementById('starter-capsules-grid');
        if (sGrid) {
            sGrid.innerHTML = '';
            STARTER_POKEMON_DB.forEach((poke, idx) => {
                const capsule = document.createElement('div');
                const sphereClass = idx === 1 ? 'great' : idx === 2 ? 'ultra' : '';
                capsule.className = `capsule-card ${idx === Store.state.selectedStarterIndex ? 'selected' : ''}`;
                capsule.innerHTML = `
                    <div class="pokeball-sphere ${sphereClass}">
                        <div class="p-top"></div>
                        <div class="p-stripe"></div>
                        <div class="p-core"></div>
                        <div class="p-bot"></div>
                    </div>
                    <div class="capsule-info">
                        <h4>${poke.name}</h4>
                        <span class="type-pill" style="background:${poke.color}">${poke.type}</span>
                        <p class="capsule-desc">${poke.lore.slice(0, 75)}...</p>
                    </div>
                `;
                capsule.onclick = () => {
                    SoundEngine.playUiClick();
                    Store.state.selectedStarterIndex = idx;
                    document.querySelectorAll('.capsule-card').forEach(el => el.classList.remove('selected'));
                    capsule.classList.add('selected');
                };
                sGrid.appendChild(capsule);
            });
        }
    }

    startQuest() {
        SoundEngine.playUiClick();
        const nameInput = document.getElementById('trainer-name-input');
        if (nameInput && nameInput.value.trim()) {
            Store.state.trainerName = nameInput.value.trim();
        }

        // Add Starter to roster if empty
        if (Store.state.caughtRoster.length === 0) {
            const starter = STARTER_POKEMON_DB[Store.state.selectedStarterIndex];
            Store.state.caughtRoster.push({
                id: starter.id,
                name: starter.name,
                type: starter.type,
                cp: 520,
                rarity: 'Starter Partner',
                sprite: starter.sprite,
                caughtDate: 'Journey Origin'
            });
            this.setSpotlight(starter);
        }

        Store.saveState();

        document.getElementById('view-onboarding').classList.remove('active');
        document.getElementById('view-gameplay').classList.add('active');

        this.renderHud();
        this.renderBallDock();
        this.renderSatchel();
        SafariZone.spawnNewWave();
    }

    renderHud() {
        const trainer = TRAINERS_DB.find(t => t.id === Store.state.selectedTrainerId) || TRAINERS_DB[0];
        document.getElementById('hud-player-name').innerText = Store.state.trainerName;
        document.getElementById('hud-player-level').innerText = `LVL ${Store.state.level}`;
        document.getElementById('hud-exp-bar').style.width = `${Store.state.exp}%`;
        document.getElementById('hud-avatar-img').src = trainer.avatar;

        document.getElementById('hud-score').innerText = Store.state.score.toLocaleString();
        document.getElementById('hud-streak').innerText = `${Store.state.streak}x`;
        document.getElementById('hud-pokedex-count').innerText = Store.state.caughtRoster.length;
        document.getElementById('satchel-count').innerText = `${Store.state.caughtRoster.length} Pokémon`;
        document.getElementById('hud-razz-count').innerText = `x${Store.state.razzBerries}`;

        this.renderBallDock();
    }

    renderBallDock() {
        const dock = document.getElementById('ball-selector-dock');
        if (!dock) return;
        dock.innerHTML = '';

        BALL_ARSENAL.forEach(ball => {
            const chip = document.createElement('button');
            chip.className = `item-chip ${Store.state.activeBall === ball.type ? 'active' : ''}`;
            chip.innerHTML = `
                <span class="chip-icon">${ball.icon}</span>
                <span class="chip-text">${ball.name}</span>
                <span class="chip-badge">x${Store.state.inventory[ball.type]}</span>
            `;
            chip.onclick = () => {
                SoundEngine.playUiClick();
                Store.state.activeBall = ball.type;
                this.renderBallDock();
            };
            dock.appendChild(chip);
        });
    }

    renderSatchel() {
        const list = document.getElementById('satchel-items-list');
        if (!list) return;
        list.innerHTML = '';

        Store.state.caughtRoster.forEach(poke => {
            const card = document.createElement('div');
            card.className = 'satchel-card';
            card.innerHTML = `
                <img src="${poke.sprite}" class="satchel-thumb" alt="${poke.name}">
                <div class="satchel-details">
                    <h5>${poke.name}</h5>
                    <span>CP ${poke.cp} • ${poke.type}</span>
                </div>
            `;
            card.onclick = () => this.setSpotlight(poke);
            list.appendChild(card);
        });
    }

    setSpotlight(poke) {
        document.getElementById('spotlight-img').src = poke.sprite;
        document.getElementById('spotlight-name').innerText = poke.name;

        const typesBox = document.getElementById('spotlight-types');
        typesBox.innerHTML = `<span class="type-pill" style="background:#3b82f6">${poke.type}</span>`;

        const statsBox = document.getElementById('spotlight-stats');
        statsBox.innerHTML = `
            <div><strong>Combat Power:</strong> ${poke.cp || 500}</div>
            <div><strong>Status:</strong> Active Partner</div>
        `;
    }

    openPokedexModal() {
        SoundEngine.playUiClick();
        const grid = document.getElementById('pokedex-entries-grid');
        grid.innerHTML = '';

        const allPokemon = [...SAFARI_POKEMON_POOL];
        allPokemon.forEach(poke => {
            const isCaught = Store.state.caughtRoster.some(p => p.name === poke.name);
            const card = document.createElement('div');
            card.className = 'pokedex-entry-card';
            card.style.opacity = isCaught ? '1' : '0.4';
            card.innerHTML = `
                <img src="${poke.sprite}" alt="${poke.name}" style="${isCaught ? '' : 'filter: grayscale(1);'}">
                <h4>${poke.name} ${isCaught ? '✅' : '🔒'}</h4>
                <p style="font-size:11px; color:#94a3b8">${poke.type} • CP ${poke.cp}</p>
                <small style="font-size:10px; color:#64748b">${isCaught ? 'Registered in Pokédex' : 'Unregistered in Safari'}</small>
            `;
            grid.appendChild(card);
        });

        document.getElementById('pokedex-modal').classList.add('active');
    }

    closePokedexModal() {
        SoundEngine.playUiClick();
        document.getElementById('pokedex-modal').classList.remove('active');
    }

    exitToMenu() {
        SoundEngine.playUiClick();
        document.getElementById('view-gameplay').classList.remove('active');
        document.getElementById('view-onboarding').classList.add('active');
    }
}

const GameApp = new SafariQuestApp();

window.addEventListener('DOMContentLoaded', () => {
    GameApp.init();
});
