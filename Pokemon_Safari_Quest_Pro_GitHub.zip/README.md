# ⚡ Pokémon Safari Quest — Modern Web Game Engine

[![Vanilla JS](https://img.shields.io/badge/JavaScript-ES6%2B-F7DF1E?logo=javascript&logoColor=black)](https://developer.mozilla.org/en-US/docs/Web/JavaScript)
[![HTML5 Canvas](https://img.shields.io/badge/HTML5-Canvas%20%26%20Audio-E34F26?logo=html5&logoColor=white)](https://developer.mozilla.org/en-US/docs/Web/API/Canvas_API)
[![CSS3 Architecture](https://img.shields.io/badge/CSS3-Modern%20Glassmorphism-1572B6?logo=css3&logoColor=white)](https://developer.mozilla.org/en-US/docs/Web/CSS)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

An enterprise-ready, portfolio-grade Pokémon safari web application built purely with **Vanilla JavaScript (ES6+)**, **HTML5 Canvas physics**, and the **Web Audio API**. Zero external NPM dependencies or heavy frameworks — fast, lightweight, and engineered for high-performance browser execution.

---

## 🎮 Key Features & System Architecture

### 1. Protagonist Roster & Perk Modifiers
- **5 Canonical Trainers:** Ash Ketchum, May, Dawn, Serena, and Brock.
- **Unique Passive Perks:** Catch bonus multipliers, evasion reduction, and friendship experience scaling.

### 2. Physics & Particle Simulation
- **Quadratic Bezier Ball Trajectories:** Real-time trajectory calculation rendered dynamically onto an HTML5 Canvas layer.
- **Ambient Ambient Canvas Particle System:** 60fps dynamic dust motes and star particles for atmospheric immersion.

### 3. Procedural Audio Synthesis (Zero Audio Files)
- Engineered with the **Web Audio API (`AudioContext`)**.
- Generates procedural sound effects (UI clicks, ball throws, victory fanfares, breakout buzzers) entirely in code using synthesized oscillator frequencies.

### 4. Interactive Pokédex & Inventory Management
- **Ball Arsenal:** Standard Poké Ball (1.0x), Great Ball (1.5x), Ultra Ball (2.0x), and Master Ball (Guaranteed 99.0x).
- **Consumable Feeding:** Razz Berry mechanics providing a temporary +35% catch rate boost.
- **Full National Pokédex Directory:** Modal inspector showing real-time encounter analytics and captured Pokémon metadata.

### 5. State Persistence
- Complete progress (Trainer Level, Experience XP, Inventory stock, and Caught collection) is serialized and persisted automatically via **`localStorage`**.

---

## 🚀 Live Demo & Deployment Guide

### Instant Local Execution
1. Clone this repository:
   ```bash
   git clone https://github.com/<your-username>/pokemon-safari-quest.git
   cd pokemon-safari-quest
   ```
2. Open `index.html` directly in any modern browser (Chrome, Edge, Safari, Firefox). No build step required!

### Free Deployment to GitHub Pages
1. Push this repository to your GitHub profile.
2. Navigate to **Settings** → **Pages**.
3. Under **Build and deployment**, select **Source: Deploy from a branch**.
4. Set branch to `main` and folder to `/root`, then click **Save**.
5. Your game will be live globally within seconds!

---

## 📂 Project Directory Structure

```plaintext
pokemon-safari-quest/
│
├── index.html        # Clean, accessible semantic HTML5 layout
├── style.css         # Modern CSS custom properties & Glassmorphism UI
├── script.js         # Modular ES6+ Object-Oriented game engine
├── README.md         # Professional documentation for GitHub
└── LICENSE           # MIT Open Source License
```

---

## 🛠️ Built With
- **Vanilla ES6+ JavaScript:** Event-driven architecture with encapsulated controllers.
- **HTML5 Canvas:** 2D rendering context for ambient dust & ball flight physics.
- **Web Audio API:** Real-time waveform synthesis.
- **Modern CSS3:** CSS Variables, Flexbox, CSS Grid, and Backdrop-filter blur.

---

## 📄 License
This project is open-source under the **MIT License**. Created as an engineering portfolio showcase.
